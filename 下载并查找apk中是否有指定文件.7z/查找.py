# -*- coding: utf-8 -*-
import os,sys,glob
import zipfile
download_path="E:\\downloadlib\\lib"
os.chdir(download_path)
path = download_path
b = []

tested_apk = []
dirs = os.listdir( path )#dirs是当前目录下所有文件名的list
#for file in dirs:
#    print(file)
path_file_number=glob.glob("*")#输出当前目录下文件数量，如果是特定文件就用*.zip之类的
c = len(path_file_number)
#print(c)
#循环读取每个文件中的lib库，如果有匹配，就记录文件名
#c = ["ww","ee.zip"]
#os.chdir("E:\\downloadlib")
for ii in range(c):
    namezip_cut = []
    read_hey = zipfile.ZipFile(dirs[ii])
    namezip = read_hey.namelist()
    for path_i in range(len(namezip)):
        namezip_cut.append(os.path.basename(namezip[path_i]))
#    print(namezip_cut)
    if "libtersafe.so" in namezip_cut or "libtersafe2.so" in namezip_cut:
        b.append(dirs[ii])
    else:
        tested_apk.append(dirs[ii])

print("包含safe库的apk",b)
print("不包含safe库的apk",tested_apk)





