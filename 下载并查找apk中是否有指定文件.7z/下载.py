# -*- coding: utf-8 -*-
import os
import xlrd
import urllib.request
import urllib.error
#re是正则库
import re
import sys
download_path="E:\\downloadlib\\lib"
os.chdir(download_path)

def download_and_extract(filepath, save_dir):
    """根据给定的URL地址下载文件
    Parameter:
        filepath: list 文件的URL路径地址
        save_dir: str  保存路径
    Return:
        None
    """
    for url, index in zip(filepath, range(len(filepath))):
#        print(str(url))
        L = re.search(r'ame=(.*).apk&csr=1bbd',str(url))
        filename = L.group(1)+".zip"
#        print(filename)
        save_path = os.path.join(save_dir, filename)
        urllib.request.urlretrieve(url, save_path)
#        sys.stdout.write('\r>> Downloading %.1f%%' % (float(index + 1) / float(len(filepath)) * 100.0))
        sys.stdout.flush()
    print('\nSuccessfully downloaded')


#打开excel
download_list = []
workbook = xlrd.open_workbook("D:\\test.xlsx")
sheets = workbook.sheets()[0]
#print(sheets)
col1=sheets.col_values(1)
b = col1
for i in range(len(col1)):
    b[i] = "https://sj.qq.com/myapp/detail.htm?apkName="+col1[i]
del b[0]
#print(b)
#删除文件，测试\\是否是正确的输入路径方式
#os.remove("D:\\daoru.xlsx")
e = []
for i in range(len(b)):
    response = urllib.request.urlopen(str(b[i]))
    s = response.read()
    f = re.search(r'https://imtt(.*?)=1bbd',str(s))
    if f :
#        print(f.group())
        download_list.append(f.group())
    else:
        j = re.search(r'apkName=(.*)',str(col1[i]))
        print("应用宝上没找到"+j.group(1))
#print(download_list)


save_dir = 'E:\\downloadlib\\lib/'
download_and_extract(download_list, save_dir)

















'''
e = []
for i in range(len(b)):
    response = urllib.request.urlopen(str(b[i]))
    for line in response:
        e.append(line)
    f = re.search(r'http(.*)=1bbd', str(e[-10]))
    print(f.group())
'''